var txtName =  document.querySelector("#txtName");
var selectCountry =  document.querySelector("#selectCountry");
txtName.addEventListener("blur",validate);
selectCountry.addEventListener("blur",validate);

//Ajax Validation on blur event(send Request To Servlet For Validation)
function validate() {
    var xhttp;       
    var params=this.name+"="+this.value;
    var apiurl = "http://localhost:8080/AjaxValidation_Exercise2/Index";
    var elementId = this.id;
    if (window.XMLHttpRequest) {
        xhttp = new XMLHttpRequest();
    } else {
        xhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
           document.getElementById(elementId +"Err").innerHTML = xhttp.responseText;
        }
    };    
    xhttp.open("POST", apiurl, true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send(params);    
}

//Js Validation Function for prevent form submition
function submitForm() {
    var flag = true;
    if(txtName.value.length===0 || (txtName.value.length<3 || txtName.value.length>31)) {
        flag=false;
    }
    if(selectCountry.value==="Select one") {
        flag=false;
    }
    if(!flag) {
        alert("Validate Form Elements first")
    } else {
        alert("Validate Success")
    }
    return false;
}