/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

/**
 *
 * @author Naresh
 */
public class Exercise2 {

    /**
     * @param args the command line arguments
     */
    public static String removeDoubledLetters(String line) {
        String result = "";
        for (int i = 0; i < line.length(); i++) {
            result += line.charAt(i);
            for (int j = i + 1; j < line.length(); j++) {
                if (line.charAt(i) == line.charAt(j)) {
                    i++;
                } else {
                    break;
                }
            }
        }
        return result;
    }

    public static void main(String[] args) {

        String line = "booooooooooooooooookepeerrrrrrrr";
        System.out.println("Old String : " + line + "\n New String : " + removeDoubledLetters(line));

        line = "qiinayaaka";
        System.out.println("\nOld String : " + line + "\n New String : " + removeDoubledLetters(line));

        line = "oooppppuuuyyytttionbgggg";
        System.out.println("\nOld String : " + line + "\n New String : " + removeDoubledLetters(line));

        line = "testiingg";
        System.out.println("\nOld String : " + line + "\n New String : " + removeDoubledLetters(line));
    }

}
