/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.util.Scanner;

/**
 *
 * @author MyPc
 */
public class Exercise5 {

    /**
     * @param args the command line arguments
     */
    private static String addCommasToNumericString(String digits) {        
        StringBuffer buffer = new StringBuffer(digits);        
        for(int i=buffer.length()-3;i>0;i-=3) {
            buffer.insert(i, ',');
        }
        return buffer.toString();
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Your Number : ");
        String digits=scanner.nextLine();
        System.out.println(addCommasToNumericString(digits));
    }
    
}

