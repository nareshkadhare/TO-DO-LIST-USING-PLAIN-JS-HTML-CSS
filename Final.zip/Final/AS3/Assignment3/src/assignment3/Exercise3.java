/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.util.Scanner;

/**
 *
 * @author MyPc
 */
public class Exercise3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        StringOperation operation = new StringOperation();
        System.out.println("O/P : " + operation.IsNameQ1());
        System.out.println("O/P : " + operation.IsNameQ2());
    }

}

class StringOperation {

    /*
     it is used to checking reference of both the "Q"(String) And Name (String)
     Both String References Are Different Thats Y : False 
     */
    public boolean IsNameQ1() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Name");
        String name = scanner.nextLine();
        return (name == "Q");
    }

    /*
     it is used to cheking variable value char 'Q' with String Name.charAt(0)='Q' both are  
     Character (Value is Compare here) not reference Thats Y : True
     */
    public boolean IsNameQ2() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Name");
        String name = scanner.nextLine();
        char ch = name.charAt(0);
        return ((ch == 'Q') && (name.length() == 1));
    }
}
