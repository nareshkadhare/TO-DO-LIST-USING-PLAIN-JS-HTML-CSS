/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.util.HashMap;
import java.util.Set;

/**
 *
 * @author Naresh
 */
public class Exercise1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        HashMap<String, String> map1 = new HashMap<>();
        HashMap<String, String> map2 = new HashMap<>();
        map1.put("Name", "Naresh");
        map1.put("Age", "25");
        map1.put("Gender", "Male");
        map1.put("Mobile", "9874563210");
        map1.put("Company", "NJ");

        map2.put("Name", "Abhinav");
        map2.put("Age", "25");        
        map2.put("Gender", "Male");
        map2.put("Mobile", "7874563210");
        map2.put("Company", "NJ");
        HashMapOperation operation =  new HashMapOperation();
        System.out.println("Common Count : "+operation.commonKeyValuePairs(map1, map2));
    }

}

class HashMapOperation {

    public int commonKeyValuePairs(HashMap<String, String> map1,
            HashMap<String, String> map2) {
        
        Set<String> map2Keys =  map2.keySet();
        int count = 0;
        for (String key : map1.keySet()) {
            if(map2Keys.contains(key) && map1.get(key).equalsIgnoreCase(map2.get(key))) {
                count++;
            }
        }
        return count;
    }
}
