/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author Naresh
 */
public class Exercise4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        List<String> names = new ArrayList<>();

        Scanner scanner = new Scanner(System.in);
        String line="";
        int i=0;
        
        Map<String,Integer> namesCounts = new HashMap<>();
        while(!(line=scanner.nextLine()).equals("")) {
            names.add(line);
        }                
        Set<String> uniqNames =  new HashSet<>(names);
        for (String name : uniqNames) {
            namesCounts.put(name, Collections.frequency(names, name));
        }
        
        System.out.println("Names With Number Of Occurence");
        for (Map.Entry<String, Integer> entrySet : namesCounts.entrySet()) {                        
            System.out.println(entrySet.getKey()+" : "+entrySet.getValue());
        }
    }
    
}
