var txtNumber = document.getElementById("txtNumber");
var btn = document.getElementById("btn");
var result = document.getElementById("result");
btn.addEventListener("click", function () {
    if(txtNumber.value.trim()!="") {
        var patt = new RegExp(/^\+?1?\s*?\(?\d{3}(?:\)|[-|\s])?\s*?\d{3}[-|\s]?\d{4}$/);
        result.style.opacity="1";
        if(patt.test(txtNumber.value.trim())){
            result.setAttribute("class","success");
            result.innerHTML = "Number is valid :  True";
        } else {
            result.setAttribute("class","danger");
            result.innerHTML = "Number is invalid :  False";
        }
    } else {
        alert("Please Enter US number");
    }
})