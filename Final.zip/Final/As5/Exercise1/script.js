﻿var x = document.getElementById("message");
var summary = document.querySelector(".summary");
var temperature = document.querySelector(".temperature");
var toggleBtn = document.querySelector("#toggleBtn");
var result = "";




function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}

function showPosition(position) {
    var xhttp;
    /*
        proxyUrl is Used For Cross-Origin Request Blocked Problem in Dark Sky Api     
    */
    var proxyUrl = "https://cors-anywhere.herokuapp.com/";
    var apiurl = proxyUrl + "https://api.darksky.net/forecast/4cd6525ebe3ade4e19d4a1bc4222b214/" + position.coords.latitude + "," + position.coords.longitude;
    if (window.XMLHttpRequest) {
        xhttp = new XMLHttpRequest();
    } else {
        xhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            result = JSON.parse(xhttp.response);
            summary.innerHTML = "Weather Type : " + result.currently.summary;
            temperature.innerHTML = "Temperature : " + result.currently.temperature + " °F";
            toggleBtn.style.opacity="1";
            setBackground(result.currently.icon);
        }
    };
    xhttp.open("GET", apiurl, true);
    xhttp.send();
}
//call getLocation to get Weather Info
getLocation();

toggleBtn.addEventListener("click", function () {    
    if (this.innerHTML == "Celsius") {
        this.innerHTML = "Fahrenheit";
        var c = (result.currently.temperature - 32) * 5 / 9;
        temperature.innerHTML = "Temperature : " + c.toFixed(2) + " °C";
    } else {
        this.innerHTML = "Celsius";
        temperature.innerHTML = "Temperature : " + result.currently.temperature + " °F";
    }
})

//Setting Image For Weather Types
function setBackground(icon) {    
    document.querySelector(".content").style.backgroundImage = "url('./img/"+icon+".jpg"+"')";
}