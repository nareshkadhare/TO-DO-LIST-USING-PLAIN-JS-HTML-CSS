var txtSentence = document.getElementById("txtSenteces");
var btn = document.getElementById("btn");
var result = document.querySelector(".result");
btn.addEventListener("click", function () {

    if (txtSentence.value.trim() != "") {
        //Define Word spliter suing regular expression
        var spliter = /[ ,_\.-/]/;
        //splits line into words
        var sentenceList = txtSentence.value.split(spliter);
        var max = 0;
        var maxLengthWord = "";
        sentenceList.forEach(element => {
            //max length compare to last max length
            if (element.length > max) {
                max = element.length;
                maxLengthWord = element;
            }
        });
        result.style.opacity = "1";
        result.innerHTML = "Longest Word Length is  : " + max;
    } else  {
        alert("Enter Your Senteces");
    }
})